package com.sdtechinc.controller;

import com.sdtechinc.vo.PropertyDetailsVO;
import com.sdtechnic.dto.PropertyDetailsDTO;
import com.sdtechnic.service.PropertyDetailsService;

public class PropertyDetailsMainController {
	PropertyDetailsService pdService;

	public PropertyDetailsMainController(PropertyDetailsService pdService) {
		this.pdService = pdService;
	}

	public String processPropertyDetails(PropertyDetailsVO vo) throws Exception {
		PropertyDetailsDTO dto = null;
		String result = null;
		// convert VO class object to DTO class object
		dto = new PropertyDetailsDTO();
		dto.setPropertyOwnerName(vo.getPropertyOwnerName());
		dto.setPropertyOwnerContact(vo.getPropertyOwnerContact());
		dto.setPropertySize(vo.getPropertySize());
		dto.setPropertyPrice(vo.getPropertyPrice());
		dto.setPropertyLocation(vo.getPropertyLocation());
		dto.setPropertAvaible(vo.isPropertAvaible());
		// use service
		result = pdService.showPropertyDetails(dto);
		return result;
	}
}
