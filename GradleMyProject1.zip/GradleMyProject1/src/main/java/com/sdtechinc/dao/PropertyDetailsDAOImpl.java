package com.sdtechinc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.sql.DataSource;

import com.sdtechnic.bo.PropertyDetailsBO;

public class PropertyDetailsDAOImpl implements PropertDetailsDAO {

	private static final String PROPERTY_DEATILS_INSERT_QUERY = "INSERT INTO SPRING_PROPERTY_DETAILS VALUES(PROPERTY_DEATILS_NO1.NEXTVAL,?,?,?,?,?,?)";
	private DataSource ds;

	public PropertyDetailsDAOImpl(DataSource ds) {
		this.ds = ds;
	}

	@Override
	public int insert(PropertyDetailsBO bo) throws Exception {
		Connection con = null;
		PreparedStatement ps = null;
		int count = 0;
		
		// get pooled jdbc connection
		con = ds.getConnection();
		// create prepared statement object
		ps = con.prepareStatement(PROPERTY_DEATILS_INSERT_QUERY);
		// set Values to Query params
		ps.setString(1, bo.getPropertyOwnerName());
		ps.setString(2, bo.getPropertyLocation());
		ps.setFloat(3, bo.getPropertyPrice());
		ps.setString(4, bo.getPropertySize());
		ps.setString(5, bo.getPropertyOwnerContact());
		ps.setBoolean(6, bo.isPropertAvaible());
		// execute the SQL query
		count = ps.executeUpdate();
		// close jdbc objs
		ps.close();
		con.close();
		return count;
	}

}
