package com.sdtechinc.dao;

import com.sdtechnic.bo.PropertyDetailsBO;

public interface PropertDetailsDAO {
	public int insert(PropertyDetailsBO bo) throws Exception;
}
