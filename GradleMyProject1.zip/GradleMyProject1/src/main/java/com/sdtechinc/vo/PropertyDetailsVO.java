package com.sdtechinc.vo;

public class PropertyDetailsVO {
	private String propertyOwnerName;
	private String propertyLocation;
	private float propertyPrice;
	private  String propertySize;
	private String propertyOwnerContact;
	private boolean isPropertAvaible;
	public String getPropertyOwnerName() {
		return propertyOwnerName;
	}
	public void setPropertyOwnerName(String propertyOwnerName) {
		this.propertyOwnerName = propertyOwnerName;
	}
	public String getPropertyLocation() {
		return propertyLocation;
	}
	public void setPropertyLocation(String propertyLocation) {
		this.propertyLocation = propertyLocation;
	}
	public float getPropertyPrice() {
		return propertyPrice;
	}
	public void setPropertyPrice(float propertyPrice) {
		this.propertyPrice = propertyPrice;
	}
	public String getPropertySize() {
		return propertySize;
	}
	public void setPropertySize(String propertySize) {
		this.propertySize = propertySize;
	}
	public String getPropertyOwnerContact() {
		return propertyOwnerContact;
	}
	public void setPropertyOwnerContact(String contact) {
		this.propertyOwnerContact = contact;
	}
	public boolean isPropertAvaible() {
		return isPropertAvaible;
	}
	public void setPropertAvaible(boolean isPropertAvaible) {
		this.isPropertAvaible = isPropertAvaible;
	}
	
}
