package com.sdtechnic.service;

import com.sdtechnic.dto.PropertyDetailsDTO;

public interface PropertyDetailsService {
	public String showPropertyDetails(PropertyDetailsDTO dto) throws Exception;
}
