package com.sdtechnic.service;

import com.sdtechinc.dao.PropertDetailsDAO;
import com.sdtechnic.bo.PropertyDetailsBO;
import com.sdtechnic.dto.PropertyDetailsDTO;

public class PropertyDetailsServiceImpl implements PropertyDetailsService {
	private PropertDetailsDAO dao;

	public PropertyDetailsServiceImpl(PropertDetailsDAO dao) {
		this.dao = dao;
	}

	@Override
	public String showPropertyDetails(PropertyDetailsDTO dto) throws Exception {
		PropertyDetailsBO bo = new PropertyDetailsBO();
		int count = 0;
		bo.setPropertyOwnerName(dto.getPropertyOwnerName());
		bo.setPropertAvaible(dto.isPropertAvaible());
		bo.setPropertyLocation(dto.getPropertyLocation());
		bo.setPropertyOwnerContact(dto.getPropertyOwnerContact());
		bo.setPropertyPrice(dto.getPropertyPrice());
		bo.setPropertySize(dto.getPropertySize());
		count = dao.insert(bo);
		if (count > 0 && bo.isPropertAvaible())
			return "Property having area of " + bo.getPropertySize() + "sq.ft with price as " + bo.getPropertyPrice()
					+ " Rupees, is located at " + bo.getPropertyLocation() + " is now avaiable. Owner name is "
					+ bo.getPropertyOwnerName() + "." + " Please Contact on " + bo.getPropertyOwnerContact()+".";
		else
			return "Property Not available";
	}

}
