package com.sdtechnic.test;

import java.util.Scanner;

import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;

import com.sdtechinc.controller.PropertyDetailsMainController;
import com.sdtechinc.vo.PropertyDetailsVO;

public class PropertyDetailsLaunch {

	public static void main(String[] args) {

		Scanner sc = null;
		DefaultListableBeanFactory beanFactory = null;
		String name = null, cadd = null, size = null;
		boolean time = false;
		float pamt = 0f;
		String contact = null;
		PropertyDetailsVO vo = null;
		DefaultListableBeanFactory factory = null;
		XmlBeanDefinitionReader reader = null;
		PropertyDetailsMainController controller = null;
		String result = null;
		// read inputs
		sc = new Scanner(System.in);
		System.out.println("enter property owner name  :: ");
		name = sc.next();
		System.out.println("Enter property location::");
		cadd = sc.next();
		System.out.println("Enter property  price::");
		pamt = sc.nextFloat();
		System.out.println("Enter property size in sq. ft::");
		size = sc.next();
		System.out.println("is property available (Y/N)   ::");
		time = sc.nextBoolean();
		System.out.println("Enter Property owner Conatct number  ::");
		contact = sc.next();
		// Store inputs in VO class object
		vo = new PropertyDetailsVO();
		vo.setPropertyOwnerName(name);
		vo.setPropertyLocation(cadd);
		vo.setPropertyPrice(pamt);
		vo.setPropertySize(size);
		vo.setPropertAvaible(time);
		vo.setPropertyOwnerContact(contact);
		// create BeanFacory IOC container
		factory = new DefaultListableBeanFactory();
		reader = new XmlBeanDefinitionReader(factory);
		
		reader.loadBeanDefinitions("com/sdtechnic/cfs/applicationContext.xml");
		// get Controller Bean class object..
		controller = factory.getBean("propertyDetailsController", PropertyDetailsMainController.class);
		// invoke the method
		try {
			result = controller.processPropertyDetails(vo);
			System.out.println(result);
		} catch (Exception e) {
			System.out.println("Internal Problem");
			e.printStackTrace();
		}
	}// main
}// class
